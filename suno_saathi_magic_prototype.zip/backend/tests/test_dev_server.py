"""Real HTTP tests: starts dev_server.py's handler on a free port and calls it with urllib."""
from __future__ import annotations

import json
import sys
import threading
import unittest
import urllib.error
import urllib.request
from http.server import ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.factory import create_service        # noqa: E402
from app.providers.mock import MockProvider    # noqa: E402
from dev_server import make_handler            # noqa: E402
from tests.test_core import settings           # noqa: E402

SITE = Path(__file__).resolve().parent.parent.parent / "website"


class Server:
    def __init__(self, env="dev", providers=None, site=None, **kw):
        self.s = settings(env=env, anon_per_minute=99, free_per_minute=99, premium_per_minute=99, **kw)
        self.service, self.auth = create_service(self.s, providers=providers if providers is not None else [MockProvider()])
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.service, self.auth, self.s, site))
        self.base = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()

    def call(self, path, body=None, headers=None, method=None):
        data = None if body is None else (body if isinstance(body, bytes) else json.dumps(body).encode())
        req = urllib.request.Request(self.base + path, data=data, method=method or ("POST" if data is not None else "GET"),
                                     headers={"Content-Type": "application/json", **(headers or {})})
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read() or b"{}"), dict(r.headers)
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                return e.code, json.loads(raw or b"{}"), dict(e.headers)
            except ValueError:
                return e.code, {}, dict(e.headers)


EXPLAIN = {"tool_id": "force-calculator", "mode": "F", "inputs": {"x": 5, "y": 3}, "lang": "en", "kind": "explain",
           "result_text": "Calculation Result\n15 N\nFormula: F = m x a\nF = 5 x 3\nF = 15 N"}


class DevServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = Server()

    @classmethod
    def tearDownClass(cls):
        cls.srv.close()

    def test_health(self):
        code, data, _ = self.srv.call("/v1/health")
        self.assertEqual((code, data["status"], data["registry_tools"], data["ai_enabled"]), (200, "ok", 38, True))

    def test_route_explain_formula_usage(self):
        code, d, _ = self.srv.call("/v1/route", {"question": "force when mass is 5 kg and acceleration is 3 m/s2", "lang": "en"},
                                   {"X-Client-Id": "t1"})
        self.assertEqual((code, d["source"], d["route"]["query"]), (200, "rules", "mode=F&x=5&y=3"))
        code, d, _ = self.srv.call("/v1/explain", EXPLAIN, {"X-Client-Id": "t1"})
        self.assertEqual((code, d["source"], d["provider"]), (200, "ai", "mock"))
        self.assertEqual(d["usage"]["used"], 1)
        code, d, _ = self.srv.call("/v1/formula", {"query": "pressure from force and area", "lang": "hi"})
        self.assertEqual((code, d["formulas"][0]["tool_id"]), (200, "pressure-calculator"))
        code, d, _ = self.srv.call("/v1/usage", headers={"X-Client-Id": "t1"})
        self.assertEqual((code, d["tier"], d["used"]), (200, "anonymous", 1))

    def test_errors(self):
        self.assertEqual(self.srv.call("/v1/route", b"not json")[0], 400)
        self.assertEqual(self.srv.call("/v1/route", b"[1,2]")[0], 400)
        self.assertEqual(self.srv.call("/v1/route", {"question": ""})[0], 400)
        self.assertEqual(self.srv.call("/v1/route", {"question": "x" * 900})[0], 413)
        self.assertEqual(self.srv.call("/v1/route", b"{" + b" " * 30000 + b"}")[0], 413)
        self.assertEqual(self.srv.call("/v1/nope", {})[0], 404)
        self.assertEqual(self.srv.call("/v1/explain", dict(EXPLAIN, tool_id="zzz"))[0], 400)

    def test_cors_preflight_and_headers(self):
        code, _, h = self.srv.call("/v1/route", method="OPTIONS", headers={"Origin": "https://sunosaathilabs.netlify.app"})
        self.assertEqual(code, 204)
        self.assertIn("X-Client-Id", h.get("Access-Control-Allow-Headers", ""))
        _, _, h = self.srv.call("/v1/health", headers={"Origin": "https://sunosaathilabs.netlify.app"})
        self.assertEqual(h.get("Access-Control-Allow-Origin"), "*")

    def test_dev_tier_header_dev_only(self):
        _, d, _ = self.srv.call("/v1/usage", headers={"X-Dev-Tier": "premium", "X-Client-Id": "p"})
        self.assertEqual(d["tier"], "premium")
        prod = Server(env="prod")
        try:
            _, d, _ = prod.call("/v1/usage", headers={"X-Dev-Tier": "premium", "X-Client-Id": "p"})
            self.assertEqual(d["tier"], "anonymous")
        finally:
            prod.close()

    def test_bad_token_is_401(self):
        self.assertEqual(self.srv.call("/v1/usage", headers={"Authorization": "Bearer abc"})[0], 401)

    def test_cors_allowlist(self):
        s = Server(cors_origins=["https://sunosaathilabs.netlify.app"])
        try:
            _, _, ok = s.call("/v1/health", headers={"Origin": "https://sunosaathilabs.netlify.app"})
            _, _, bad = s.call("/v1/health", headers={"Origin": "https://evil.example"})
            self.assertEqual(ok.get("Access-Control-Allow-Origin"), "https://sunosaathilabs.netlify.app")
            self.assertIsNone(bad.get("Access-Control-Allow-Origin"))
        finally:
            s.close()

    def test_quota_over_http(self):
        s = Server(anon_daily=2, global_daily=100)
        try:
            srcs = [s.call("/v1/explain", EXPLAIN, {"X-Client-Id": "q"})[1]["source"] for _ in range(4)]
            self.assertEqual(srcs, ["ai", "ai", "template", "template"])
            _, d, _ = s.call("/v1/explain", EXPLAIN, {"X-Client-Id": "q"})
            self.assertEqual(d["degraded_reason"], "user_daily")
        finally:
            s.close()

    def test_static_site_is_served_when_configured(self):
        if not (SITE / "index.html").exists():
            self.skipTest("website folder not present")
        s = Server(site=SITE)
        try:
            req = urllib.request.urlopen(s.base + "/physics/force-calculator", timeout=5)
            self.assertEqual(req.status, 200)
            self.assertEqual(urllib.request.urlopen(s.base + "/", timeout=5).status, 200)
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(s.base + "/../backend/dev_server.py", timeout=5)
            self.assertIn(cm.exception.code, (403, 404))
            with self.assertRaises(urllib.error.HTTPError) as cm:
                urllib.request.urlopen(s.base + "/%2e%2e/backend/dev_server.py", timeout=5)
            self.assertIn(cm.exception.code, (403, 404))
        finally:
            s.close()


if __name__ == "__main__":
    unittest.main()
