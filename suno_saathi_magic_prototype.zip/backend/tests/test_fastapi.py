"""Runs only where FastAPI + httpx are installed (your PC / the deployed environment).
It repeats the key HTTP checks against the real FastAPI app in app/main.py.

    pip install -r requirements.txt httpx
    python -m unittest tests.test_fastapi -v
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

try:
    from fastapi.testclient import TestClient   # needs httpx
    HAVE = True
except Exception:                               # pragma: no cover
    HAVE = False

from tests.test_core import settings            # noqa: E402


@unittest.skipUnless(HAVE, "FastAPI/httpx not installed in this environment")
class FastAPITests(unittest.TestCase):
    def setUp(self):
        from app.main import create_app
        s = settings(enable_mock_provider=True, ai_providers=["mock"], anon_per_minute=99)
        self.client = TestClient(create_app(s))

    def test_health(self):
        r = self.client.get("/v1/health")
        self.assertEqual((r.status_code, r.json()["status"]), (200, "ok"))

    def test_route_and_explain(self):
        r = self.client.post("/v1/route", json={"question": "force when mass is 5 kg and acceleration is 3 m/s2"})
        self.assertEqual(r.json()["route"]["query"], "mode=F&x=5&y=3")
        r = self.client.post("/v1/explain", json={"tool_id": "force-calculator", "mode": "F", "inputs": {"x": 5, "y": 3},
                                                  "result_text": "15 N\nF = 5 x 3", "lang": "hi"})
        self.assertEqual(r.status_code, 200)
        self.assertIn("source", r.json())

    def test_errors_and_cors(self):
        self.assertEqual(self.client.post("/v1/route", content=b"nope", headers={"Content-Type": "application/json"}).status_code, 400)
        self.assertEqual(self.client.post("/v1/route", json={"question": ""}).status_code, 400)
        r = self.client.options("/v1/route", headers={"Origin": "https://x.example", "Access-Control-Request-Method": "POST",
                                                      "Access-Control-Request-Headers": "content-type,x-client-id"})
        self.assertIn(r.status_code, (200, 204))


if __name__ == "__main__":
    unittest.main()
